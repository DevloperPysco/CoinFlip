package me.yourname.coinflip;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class CoinflipPlugin extends JavaPlugin implements Listener, CommandExecutor {

    private final String GUI_TITLE = ChatColor.GOLD + "Coinflip - Choose Side";
    private Economy economy;
    private final Map<Player, Double> betMap = new HashMap<>();

    @Override
    public void onEnable() {
        if (!setupEconomy()) {
            getLogger().severe("Vault dependency not found! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getServer().getPluginManager().registerEvents(this, this);
        this.getCommand("coinflip").setExecutor(this);
        getLogger().info("Coinflip plugin enabled.");
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        economy = rsp.getProvider();
        return economy != null;
    }

    @Override
    public void onDisable() {
        getLogger().info("Coinflip plugin disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        Player player = (Player) sender;

        double betAmount = 100.0;
        if (args.length == 1) {
            try {
                betAmount = Double.parseDouble(args[0]);
                if (betAmount <= 0) {
                    player.sendMessage(ChatColor.RED + "Please enter a positive bet amount.");
                    return true;
                }
            } catch (NumberFormatException e) {
                player.sendMessage(ChatColor.RED + "Invalid amount. Usage: /coinflip [amount]");
                return true;
            }
        }

        if (!economy.has(player, betAmount)) {
            player.sendMessage(ChatColor.RED + "You need at least $" + betAmount + " to play coinflip.");
            return true;
        }

        betMap.put(player, betAmount);
        openCoinflipGUI(player);
        return true;
    }

    private void openCoinflipGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 9, GUI_TITLE);

        ItemStack heads = new ItemStack(Material.GOLD_INGOT);
        ItemMeta headsMeta = heads.getItemMeta();
        headsMeta.setDisplayName(ChatColor.GREEN + "Heads");
        heads.setItemMeta(headsMeta);

        ItemStack tails = new ItemStack(Material.IRON_INGOT);
        ItemMeta tailsMeta = tails.getItemMeta();
        tailsMeta.setDisplayName(ChatColor.RED + "Tails");
        tails.setItemMeta(tailsMeta);

        gui.setItem(3, heads);
        gui.setItem(5, tails);

        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().equals(GUI_TITLE)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player)) return;

            Player player = (Player) event.getWhoClicked();
            ItemStack clickedItem = event.getCurrentItem();
            if (clickedItem == null || !clickedItem.hasItemMeta()) return;

            String choice = ChatColor.stripColor(clickedItem.getItemMeta().getDisplayName());
            String result = new Random().nextBoolean() ? "Heads" : "Tails";

            double betAmount = betMap.getOrDefault(player, 100.0);

            if (!economy.has(player, betAmount)) {
                player.sendMessage(ChatColor.RED + "You no longer have enough money to play.");
                player.closeInventory();
                return;
            }

            economy.withdrawPlayer(player, betAmount);

            if (choice.equalsIgnoreCase(result)) {
                double winnings = betAmount * 2;
                economy.depositPlayer(player, winnings);
                player.sendMessage(ChatColor.GREEN + "You won the coinflip! You chose " + choice + " and it landed on " + result + ".");
                player.sendMessage(ChatColor.GREEN + "You won $" + betAmount + "!");
            } else {
                player.sendMessage(ChatColor.RED + "You lost the coinflip. You chose " + choice + " but it landed on " + result + ".");
                player.sendMessage(ChatColor.RED + "You lost $" + betAmount + ".");
            }

            player.closeInventory();
            betMap.remove(player);
        }
    }
}